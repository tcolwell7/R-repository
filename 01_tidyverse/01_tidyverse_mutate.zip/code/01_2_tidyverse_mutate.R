## Tidyverse - mutate

# Set up ------

library(tidyverse)
library(openxlsx) 
library(janitor)
library(readxl)
library(stringr)

path<-setwd(stringr::str_extract(rstudioapi::getActiveDocumentContext()$path,".+[/]")) 

`%notin%` <- Negate(`%in%`) # Custom negate function

#upload data

trade_data <- read_excel("..\\data\\trade_data.xlsx") %>% clean_names()
tariff_data <- read_excel("..\\data\\tariff_data.xlsx")

# Mutate - create columns -----------------------------------------------
# create and update columns using mutate

df <- trade_data %>% 
  mutate(
    value_gbp2 = value_gbp * 1000,
    value_gbp3 = value_gbp * 1000000
    )


df <- df  %>% mutate(newCol = paste0(commodity_code,"_",year))


# select specific column and drop non-numeric characters 


df2 <- df %>% 
  mutate(
    commodity_code = parse_number(commodity_code),
    newCol = parse_number(newCol)
  )

# Alternattively you can use "mutate_at" instead of listing each column individually

df2 <- df %>% 
  mutate_at(
    c("commodity_code", "newCol"), 
    .funs = parse_number
  ) 



# convert numeric columns to character
df3 <- df2 %>% mutate_if(is.numeric, .funs = as.character)
# OR
df3 <- df2 %>% mutate(across(where(is.numeric), ~ as.character(.x)))

# multiply all numerical values by 1000             
df3 <- df2 %>% mutate(across(where(is.numeric), ~ .x * 1000))


## Mutate across variables -----
## combining mutate > across > where is very useful and efficient when applying functions to multiple columns.  


df <- 
  tariff_data %>% 
  select(
    starts_with("commodity_code"),
    mfn_applied_duty_rate,
    num_range(
      "preferential_applied_duty_rate_",
      2021:2024
    )
  )

# want to convert tariffs to numeric. Need to remove '%'
# This can be done using str_remove in the stringr package. 

df2 <-
  df %>%
  mutate(
    preferential_applied_duty_rate_2021 = str_remove(preferential_applied_duty_rate_2021, "%"),
    preferential_applied_duty_rate_2022 = str_remove(preferential_applied_duty_rate_2022, "%"),
    preferential_applied_duty_rate_2023 = str_remove(preferential_applied_duty_rate_2023, "%"),
    preferential_applied_duty_rate_2024 = str_remove(preferential_applied_duty_rate_2024, "%")
  )

# single string function to remove "%"
stringRemove <- function(.x)(str_remove_all(.x,"%"))

df2 <- df %>% 
  mutate_at(
    c("preferential_applied_duty_rate_2021",
      "preferential_applied_duty_rate_2022",
      "preferential_applied_duty_rate_2023",
      "preferential_applied_duty_rate_2024"
    ), 
    .funs = stringRemove
  )

df2 <- df %>% mutate_if(is.character, .funs = stringRemove)

# combine mutate at (select specific columns) with pattern recognition:
df2 <- df %>% mutate_at(vars(contains("pref")), .funs = stringRemove)
df2 <- df %>% mutate_at(vars(contains("mfn")),  .funs = stringRemove)

# alternatively if columns don't have a single patterns:

df2 <- 
  df %>% 
  mutate(
    across(
      .cols = 
        c(preferential_applied_duty_rate_2021:preferential_applied_duty_rate_2024), 
         ~ str_remove_all(.x, "%")
      )
    )

# alternatively:


df2 <- 
  df %>% 
  mutate(
    across(
      .cols = 
        contains("pref"), 
      ~ str_remove_all(.x, "%")
      )
    )

## reduce notation using column index: (.cols is optional, function works without specifying)

df2 <-
  df %>%
  mutate(
    across(c(4:7), ~ str_remove_all(.x, "%"))
  )

#' remove % from all tariff columns and covert to numeric and calculate average tariff. 
#' -c(1:2) all columns except the first two
#' 

df2 <-
  df %>%
  mutate(
    across(
      -c(1:2), ~ str_remove_all(.x, "%")
    )
  ) %>%
  mutate(
    across(
      -c(1:2), ~ as.numeric(.x)
    )
  ) %>%
  mutate(
    average_pref_tariff = rowMeans(across(-c(1:3)), na.rm = T)
  )


