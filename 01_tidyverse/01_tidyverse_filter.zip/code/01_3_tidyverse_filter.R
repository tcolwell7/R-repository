## Tidyverse - filter

# Set up ------

library(tidyverse)
library(openxlsx) 
library(janitor)
library(readxl)
library(stringr)

path<-setwd(stringr::str_extract(rstudioapi::getActiveDocumentContext()$path,".+[/]")) 

`%notin%` <- Negate(`%in%`) # Custom negate function

#upload data

trade_data <- read_excel("..\\data\\trade_data.xlsx") %>% clean_names()
tariff_data <- read_excel("..\\data\\tariff_data.xlsx")

## Filter ------------------

#' Filter function and expanding on its use
#' Examples:
#' 
#' 1. Filter using operators 
#' 2. Filter using arrays and filtering using dataframes
#' 3. Filter using conditional logic
#' 4. Filter multiple variables
#'


# Filter data sets referring to pre-calculated values, arrays and text. 


df <- trade_data %>% filter(value_gbp >= 200000)
df <- trade_data %>% filter(value_gbp >= mean(value_gbp, na.rm = T))

filterValue = 1000000

df <- trade_data %>% filter(value_gbp => filterValue)


## filter using AND | OR operators ------------------

# & for and | for or
# filter for Taiwan or Thailand

df <- trade_data %>% filter(country_name == "Taiwan" | country_name == "Thailand")

# filer for exports and Taiwan

df <- trade_data %>% filter(country_name == "Taiwan" & flow == "Exports")

# + filter if value is greater than 10,000,000

df <- trade_data %>% 
  filter(
    country_name == "Taiwan" & 
    flow == "Exports" & 
    value_gbp >= 10000000
  )

# combine multiple filtering conditions using and / or. 


df <- trade_data %>% 
  filter(
    (country_name == "Taiwan" & 
     flow == "Exports" & 
     value_gbp >= 10000000)
    |
    (country_name == "Thailand" & 
     flow == "Imports" & 
     value_gbp >= 10000000)
  )


### filter by array ----------------------------------

# filter df based on commodity code list. 

array <- c("array1","array2")

df <- trade_data %>% filter(commodity_code %in% c("01012100","48084000"))

# alternatively :

df <- trade_data %>% filter(commodity_code == "01012100" | commodity_code == "48084000")


# filter based on codes *not* being in list:

codeList <- c("01012100", "02031913","02032290","03071190","04063010","11071099")

#custom negate function

`%notin%` <- Negate(`%in%`) # Custom negate function

df2 <- trade_data %>% filter(commodity_code %notin% codeList)

df2 <- trade_data %>% filter(commodity_code %notin% codeList)
df2 <- trade_data %>% filter(year %notin% c("2020"))

# you can use not in / in base don another dataframes column:

df <-  head(trade_data,10)
df2 <- head(trade_data,30)

# filter df2 if codes in df1 

df3 <- df2 %>% filter(commodity_code %in% df$commodity_code)
df3 <- df2 %>% filter(!(commodity_code %in% df$commodity_code)) # not filtwr

df3 <- df2 %>% filter(commodity_code %notin% df$commodity_code)


####  conditional filtering ----------------------------------------------

# conditional formatting:
# filter data based on select input:
# For example, if a user whats to filter based on hs2, hs4 etc. 

# create hs columns:
df <- trade_data %>% 
  mutate(
    hs2 = str_sub(commodity_code,1,2),
    hs4 = str_sub(commodity_code, 1, 4), 
    hs6 = str_sub(commodity_code, 1, 6)
  )

input <- "hs2"
code <- "02"


df4 <- df %>%
  {if(input == "hs2") filter(., hs2 == code)
    else if(input == "hs4") filter(., hs4 == code)
    else if(input == "hs6") filter(., hs6 == code) else .} %>%
  mutate(col = paste0("input_type_", input))


## I previously used:

if(input == "hs2"){
  
  df4 <- df %>% filter(hs2 == code)
    
} else if(input == "hs4"){
  
  df4 <- df %>% filter(hs4 == code)
  
} else if(input == "hs6"){
  
  df4 <- df %>% filter(hs6 == code)
} else{
  
  df
}

df4 <- df4 %>% mutate(col = paste0("input_type_", input))


# commonly used where user inputs generate outputs, i.e. within functions:
returnDF <- function(.input, .code, df){
  
  df4 <- df %>%
    {if(.input == "hs2") filter(., hs2 == .code)
      else if(.input == "hs4") filter(., hs4 == .code)
      else if(.input == "hs6") filter(., hs6 == .code) else .}
}

df_test <- returnDF("hs2","04", df)


#' separate logic - not based on user input:
#' test defined logic e.g dataframe length
#' example below used taken from a web scrape 
#' where the column numbers scrapped 
#' varied between 5 and 6

df4 <- df3 %>%
  {if(ncol(df3) == 6) select(.,1:5)
    else select(., 1:6)} %>%
  row_to_names(row_number = 1)

  ##### filter multiple columns --------------------------------------------

# filter any trade value is less than 100

df <- trade_data %>%
  mutate(value_gbp2 = value_gbp / 10) %>%
  filter_at(
    vars(value_gbp,value_gbp2), 
    any_vars(. < 10)
  ) 

# filter for NAs
df <- trade_data %>%
  mutate(value_gbp2 = value_gbp / 10) %>%
  filter_at(
    vars(value_gbp,value_gbp2), 
    any_vars(is.na(.))
  ) 


# filter for MFN rate not equal to 0
df <-  tariff_data %>% 
  select(
    starts_with("commodity_code"),
    mfn_applied_duty_rate,
    num_range(
      "preferential_applied_duty_rate_",
      2021:2024
    )
  ) 


df2 <- df %>%
  filter_at(
    vars(contains("mfn")),
    any_vars(. != "0%")
  )



# filter df using tidy select of columns using if any and starts with
df <- tariff_data %>% 
  filter(
    if_any(
      starts_with("pref"), ~ (.x == "0%")
    )
  )

# using filter across
df <- tariff_data %>%
  filter(
    across(
      c(
        preferential_applied_duty_rate_2021:
        preferential_applied_duty_rate_2024
        ),
      ~ (.x == "0%")
      )
    )
        

# alternativly:

df2 <- tariff_data %>%
  filter(
    preferential_applied_duty_rate_2021 == "0%" |
    preferential_applied_duty_rate_2022 == "0%" |
    preferential_applied_duty_rate_2023 == "0%" |
    preferential_applied_duty_rate_2024 == "0%"
  )



###### automated QA check ----------

df <- head(trade_data,50)
df2 <- head(trade_data,50) %>% mutate(value_gbp2 = value_gbp)

df2$year <- as.numeric(df2$year)

df_qa2 <- compare_df_cols(
  df,
  df2,
  return = c("all"),
  bind_method = c("bind_rows", "rbind"),
  strict_description = FALSE
) %>%
  filter(across(c(df,df2), ~ !is.na(.))) %>% # ignore NA vlaues for this check
  mutate(col_check = df == df2)

colTypeCheck <- df_qa2 %>% filter(col_check == FALSE)


if(nrow(colTypeCheck) > 0){
  abort(c("Col types are different for ",unique(colTypeCheck$column_name)))
} else{
  rbind(df,df2)
}


## \\ outcome with method one cleaner and more concise code! 