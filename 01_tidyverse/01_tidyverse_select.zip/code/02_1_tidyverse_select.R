## 02 Tidyverse function examples. 

## /// Day to day functions I use using tidyverse for data wrangling, transformaitons, cleaning and aggregaiton to produce useable outputs. 

## function areas to cover: Selecting columns, creating columns, filtering, aggregations, duplicates, seperating delimiters. 

# Set up ------

library(tidyverse)
library(openxlsx) 
library(janitor)
library(readxl)
library(stringr)

path<-setwd(stringr::str_extract(rstudioapi::getActiveDocumentContext()$path,".+[/]")) 

#upload data

tariff_data <- read_excel("..\\data\\tariff_data.xlsx")

## 1.  Select -------

# /// There are multiple ways to select columns within a dataframe:
##    1. Base R
##    2. Select using column Index
##    3. Select using column names
##    4. Select using combination 

# //// Select the commodity code, MFN and preferential tariff columns. 

# 1. Using Base R and Index numbers (time consuming searching for each number manually

print(colnames(tariff_data))

df <- tariff_data[,c(2,4,5,6,7,8,9,18)]
# OR //
df <- tariff_data[,c("commodity_code",
                     "commodity_code_description","mfn_applied_duty_rate",
                     "preferential_applied_duty_rate_2021",
                     "preferential_applied_duty_rate_2022",
                     "preferential_applied_duty_rate_2023",
                     "preferential_applied_duty_rate_2024",
                     "mfn_applied_rate_ukgt")]


# Select function:

df <- tariff_data %>% select(2,4,5,6:9,18)


df <- tariff_data %>% select(starts_with("commodity_code"),
                             starts_with("preferential"), # This captures an unwanted column "preferential_applied_duty_rate_excluded"
                             #  starts_with(c("commodity_code","preferential")), 
                             contains("mfn"))


df <- tariff_data %>% select(starts_with("commodity_code"),
                             contains("mfn"),
                             num_range("preferential_applied_duty_rate_",2021:2024))

# remove MFN columns

df <- df %>% select(-contains("mfn"))
# OR
df <- df %>% select(!contains("mfn"))
# select 2022 columns:
df <- tariff_data %>% select(commodity_code, ends_with("2022"))

# select numerical columns:
df <- tariff_data %>% select(commodity_code,where(is.numeric))

# select non-numerical columns:
df <- tariff_data %>% select(commodity_code, !where(is.numeric))

### 1i. Relocate ------

# relocate select column positioning based on other column location. For example you want to relocate a column before or after another. 
print(colnames(tariff_data))


# You can relocate columns manually using select: i.e. select(1,2,4,3,5,6... ) etc. 
# This can be laborious and inefficient (typing each column out) 
# and prone to error if the df order changes if using column indexing. 


df <- tariff_data %>% select(starts_with("commodity_code"),
                             contains("mfn"),
                             num_range("preferential_applied_duty_rate_",2021:2024),
                             where(where(is.numeric)))


df2 <- df  %>% relocate(x8_digit_or_10_digit, .after = "commodity_code")
df2 <- df2 %>% relocate(cn8_count, .after = "x8_digit_or_10_digit")
df2 <- df2 %>% relocate(value_usd, .before = "commodity_code_description")

df2 <- 
  df %>%
  relocate(c("x8_digit_or_10_digit","cn8_count"), .after = "commodity_code")

# relocate numerical only columns:

df2 <-
  df %>%
  relocate(where(is.numeric), .before = "commodity_code_description")


